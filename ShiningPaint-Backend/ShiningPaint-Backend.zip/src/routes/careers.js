const express = require('express');
const { getAllCareers, getAllCareersAdmin, getCareerById, createCareer, updateCareer, deleteCareer, applyForJob } = require('../controllers/careersController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.get('/', getAllCareers);
router.post('/apply', applyForJob);
router.get('/admin', protect, authorize('admin', 'manager'), getAllCareersAdmin);
router.get('/:id', getCareerById);
router.post('/', protect, authorize('admin', 'manager'), createCareer);
router.put('/:id', protect, authorize('admin', 'manager'), updateCareer);
router.delete('/:id', protect, authorize('admin', 'manager'), deleteCareer);

module.exports = router;
