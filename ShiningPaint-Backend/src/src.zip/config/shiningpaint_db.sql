-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2025 at 08:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: ` Shinningpaint_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'USA',
  `customer_type` enum('retail','wholesale','contractor') DEFAULT 'retail',
  `credit_limit` decimal(12,2) DEFAULT 0.00,
  `payment_terms` varchar(50) DEFAULT 'net_30',
  `tax_id` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `company_name`, `contact_person`, `email`, `phone`, `address`, `city`, `state`, `postal_code`, `country`, `customer_type`, `credit_limit`, `payment_terms`, `tax_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'ABC Construction Co.', 'John Smith', 'john@abcconstruction.com', '+1-555-1001', '123 Main St', 'New York', 'NY', '10001', 'USA', 'contractor', 10000.00, 'net_30', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(2, 'Home Depot Store #1234', 'Sarah Johnson', 'sarah@homedepot.com', '+1-555-1002', '456 Oak Ave', 'Los Angeles', 'CA', '90001', 'USA', 'wholesale', 50000.00, 'net_30', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(3, NULL, 'Mike Wilson', 'mike.wilson@email.com', '+1-555-1003', '789 Pine St', 'Chicago', 'IL', '60601', 'USA', 'retail', 1000.00, 'net_30', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_transactions`
--

CREATE TABLE `inventory_transactions` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `transaction_type` enum('in','out','adjustment') NOT NULL,
  `quantity` int(11) NOT NULL,
  `reference_type` enum('purchase','sale','adjustment','return') NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` enum('pending','confirmed','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `required_date` date DEFAULT NULL,
  `shipped_date` timestamp NULL DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `tax_amount` decimal(12,2) DEFAULT 0.00,
  `shipping_amount` decimal(12,2) DEFAULT 0.00,
  `discount_amount` decimal(12,2) DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL,
  `payment_status` enum('pending','partial','paid','refunded') DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `shipping_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`shipping_address`)),
  `billing_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`billing_address`)),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `sku` varchar(100) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `min_stock_level` int(11) DEFAULT 10,
  `max_stock_level` int(11) DEFAULT 1000,
  `unit` varchar(50) DEFAULT 'liters',
  `color_code` varchar(7) DEFAULT NULL,
  `finish_type` varchar(50) DEFAULT NULL,
  `coverage_area` decimal(8,2) DEFAULT NULL,
  `drying_time` varchar(100) DEFAULT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `specifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`specifications`)),
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `sku`, `category_id`, `price`, `cost_price`, `stock_quantity`, `min_stock_level`, `max_stock_level`, `unit`, `color_code`, `finish_type`, `coverage_area`, `drying_time`, `images`, `specifications`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Premium Interior Latex Paint - White', 'High-quality latex paint perfect for interior walls', 'PIL-WHT-001', 1, 45.99, 28.50, 150, 10, 1000, 'gallons', '#FFFFFF', 'Satin', 400.00, '2-4 hours', '[]', '{}', 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(2, 'Exterior Acrylic Paint - Blue', 'Weather-resistant acrylic paint for exterior surfaces', 'EAP-BLU-002', 2, 52.99, 32.00, 85, 10, 1000, 'gallons', '#0066CC', 'Semi-gloss', 350.00, '4-6 hours', '[]', '{}', 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(3, 'Multi-Surface Primer', 'Universal primer for various surfaces', 'MSP-WHT-003', 3, 38.99, 24.00, 120, 10, 1000, 'gallons', '#F5F5F5', 'Flat', 450.00, '1-2 hours', '[]', '{}', 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(4, 'Metallic Finish Paint - Gold', 'Decorative metallic finish paint', 'MFP-GLD-004', 4, 68.99, 42.00, 45, 10, 1000, 'quarts', '#FFD700', 'Metallic', 100.00, '6-8 hours', '[]', '{}', 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(5, 'Professional Paint Brush Set', 'Set of 5 professional-grade paint brushes', 'PBS-PRO-005', 5, 24.99, 15.00, 200, 10, 1000, 'sets', NULL, NULL, NULL, NULL, '[]', '{}', 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `name`, `description`, `parent_id`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(2, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(3, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(4, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(5, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-17 16:47:59', '2025-08-17 16:47:59'),
(6, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-17 16:48:25', '2025-08-17 16:48:25'),
(7, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-17 16:48:25', '2025-08-17 16:48:25'),
(8, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-17 16:48:25', '2025-08-17 16:48:25'),
(9, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-17 16:48:25', '2025-08-17 16:48:25'),
(10, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-17 16:48:25', '2025-08-17 16:48:25'),
(11, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-17 16:48:34', '2025-08-17 16:48:34'),
(12, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-17 16:48:34', '2025-08-17 16:48:34'),
(13, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-17 16:48:34', '2025-08-17 16:48:34'),
(14, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-17 16:48:34', '2025-08-17 16:48:34'),
(15, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-17 16:48:34', '2025-08-17 16:48:34'),
(16, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-17 17:41:43', '2025-08-17 17:41:43'),
(17, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-17 17:41:43', '2025-08-17 17:41:43'),
(18, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-17 17:41:43', '2025-08-17 17:41:43'),
(19, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-17 17:41:43', '2025-08-17 17:41:43'),
(20, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-17 17:41:43', '2025-08-17 17:41:43'),
(21, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 07:00:40', '2025-08-18 07:00:40'),
(22, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 07:00:40', '2025-08-18 07:00:40'),
(23, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 07:00:40', '2025-08-18 07:00:40'),
(24, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 07:00:41', '2025-08-18 07:00:41'),
(25, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 07:00:41', '2025-08-18 07:00:41'),
(26, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 07:12:07', '2025-08-18 07:12:07'),
(27, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 07:12:07', '2025-08-18 07:12:07'),
(28, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 07:12:07', '2025-08-18 07:12:07'),
(29, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 07:12:07', '2025-08-18 07:12:07'),
(30, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 07:12:07', '2025-08-18 07:12:07'),
(31, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 07:19:15', '2025-08-18 07:19:15'),
(32, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 07:19:15', '2025-08-18 07:19:15'),
(33, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 07:19:15', '2025-08-18 07:19:15'),
(34, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 07:19:15', '2025-08-18 07:19:15'),
(35, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 07:19:15', '2025-08-18 07:19:15'),
(36, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 07:21:27', '2025-08-18 07:21:27'),
(37, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 07:21:27', '2025-08-18 07:21:27'),
(38, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 07:21:27', '2025-08-18 07:21:27'),
(39, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 07:21:27', '2025-08-18 07:21:27'),
(40, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 07:21:27', '2025-08-18 07:21:27'),
(41, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 07:49:24', '2025-08-18 07:49:24'),
(42, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 07:49:24', '2025-08-18 07:49:24'),
(43, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 07:49:24', '2025-08-18 07:49:24'),
(44, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 07:49:24', '2025-08-18 07:49:24'),
(45, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 07:49:24', '2025-08-18 07:49:24'),
(46, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 09:35:31', '2025-08-18 09:35:31'),
(47, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 09:35:31', '2025-08-18 09:35:31'),
(48, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 09:35:32', '2025-08-18 09:35:32'),
(49, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 09:35:33', '2025-08-18 09:35:33'),
(50, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 09:35:34', '2025-08-18 09:35:34'),
(51, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 10:59:54', '2025-08-18 10:59:54'),
(52, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 10:59:54', '2025-08-18 10:59:54'),
(53, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 10:59:54', '2025-08-18 10:59:54'),
(54, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 10:59:54', '2025-08-18 10:59:54'),
(55, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 10:59:54', '2025-08-18 10:59:54'),
(56, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:00:57', '2025-08-18 11:00:57'),
(57, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:00:57', '2025-08-18 11:00:57'),
(58, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:00:57', '2025-08-18 11:00:57'),
(59, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:00:57', '2025-08-18 11:00:57'),
(60, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:00:57', '2025-08-18 11:00:57'),
(61, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:04:06', '2025-08-18 11:04:06'),
(62, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:04:06', '2025-08-18 11:04:06'),
(63, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:04:06', '2025-08-18 11:04:06'),
(64, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:04:06', '2025-08-18 11:04:06'),
(65, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:04:06', '2025-08-18 11:04:06'),
(66, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:05:21', '2025-08-18 11:05:21'),
(67, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:05:21', '2025-08-18 11:05:21'),
(68, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:05:21', '2025-08-18 11:05:21'),
(69, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:05:21', '2025-08-18 11:05:21'),
(70, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:05:21', '2025-08-18 11:05:21'),
(71, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:07:12', '2025-08-18 11:07:12'),
(72, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:07:12', '2025-08-18 11:07:12'),
(73, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:07:12', '2025-08-18 11:07:12'),
(74, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:07:12', '2025-08-18 11:07:12'),
(75, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:07:12', '2025-08-18 11:07:12'),
(76, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:09:30', '2025-08-18 11:09:30'),
(77, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:09:30', '2025-08-18 11:09:30'),
(78, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:09:30', '2025-08-18 11:09:30'),
(79, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:09:30', '2025-08-18 11:09:30'),
(80, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:09:30', '2025-08-18 11:09:30'),
(81, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:31:05', '2025-08-18 11:31:05'),
(82, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:31:05', '2025-08-18 11:31:05'),
(83, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:31:05', '2025-08-18 11:31:05'),
(84, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:31:05', '2025-08-18 11:31:05'),
(85, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:31:05', '2025-08-18 11:31:05'),
(86, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:49:50', '2025-08-18 11:49:50'),
(87, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:49:51', '2025-08-18 11:49:51'),
(88, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:49:51', '2025-08-18 11:49:51'),
(89, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:49:51', '2025-08-18 11:49:51'),
(90, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:49:51', '2025-08-18 11:49:51'),
(91, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:52:35', '2025-08-18 11:52:35'),
(92, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:52:36', '2025-08-18 11:52:36'),
(93, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:52:36', '2025-08-18 11:52:36'),
(94, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:52:36', '2025-08-18 11:52:36'),
(95, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:52:36', '2025-08-18 11:52:36'),
(96, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:54:25', '2025-08-18 11:54:25'),
(97, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:54:25', '2025-08-18 11:54:25'),
(98, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:54:25', '2025-08-18 11:54:25'),
(99, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:54:25', '2025-08-18 11:54:25'),
(100, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:54:25', '2025-08-18 11:54:25'),
(101, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:56:35', '2025-08-18 11:56:35'),
(102, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:56:35', '2025-08-18 11:56:35'),
(103, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:56:35', '2025-08-18 11:56:35'),
(104, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:56:35', '2025-08-18 11:56:35'),
(105, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:56:35', '2025-08-18 11:56:35'),
(106, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 11:58:50', '2025-08-18 11:58:50'),
(107, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 11:58:50', '2025-08-18 11:58:50'),
(108, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 11:58:50', '2025-08-18 11:58:50'),
(109, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 11:58:50', '2025-08-18 11:58:50'),
(110, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 11:58:50', '2025-08-18 11:58:50'),
(111, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-18 12:02:01', '2025-08-18 12:02:01'),
(112, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-18 12:02:01', '2025-08-18 12:02:01'),
(113, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-18 12:02:01', '2025-08-18 12:02:01'),
(114, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-18 12:02:01', '2025-08-18 12:02:01'),
(115, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-18 12:02:01', '2025-08-18 12:02:01'),
(116, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-21 07:42:37', '2025-08-21 07:42:37'),
(117, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-21 07:42:37', '2025-08-21 07:42:37'),
(118, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-21 07:42:37', '2025-08-21 07:42:37'),
(119, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-21 07:42:37', '2025-08-21 07:42:37'),
(120, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-21 07:42:37', '2025-08-21 07:42:37'),
(121, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-08-21 13:45:36', '2025-08-21 13:45:36'),
(122, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-08-21 13:45:36', '2025-08-21 13:45:36'),
(123, 'Primer', 'Base coats and primers', NULL, 1, '2025-08-21 13:45:36', '2025-08-21 13:45:36'),
(124, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-08-21 13:45:36', '2025-08-21 13:45:36'),
(125, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-08-21 13:45:36', '2025-08-21 13:45:36'),
(126, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-12-04 16:36:58', '2025-12-04 16:36:58'),
(127, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-12-04 16:36:58', '2025-12-04 16:36:58'),
(128, 'Primer', 'Base coats and primers', NULL, 1, '2025-12-04 16:36:58', '2025-12-04 16:36:58'),
(129, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-12-04 16:36:58', '2025-12-04 16:36:58'),
(130, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-12-04 16:36:58', '2025-12-04 16:36:58'),
(131, 'Interior Paint', 'Paint for interior walls and surfaces', NULL, 1, '2025-12-12 07:00:28', '2025-12-12 07:00:28'),
(132, 'Exterior Paint', 'Weather-resistant paint for outdoor use', NULL, 1, '2025-12-12 07:00:28', '2025-12-12 07:00:28'),
(133, 'Primer', 'Base coats and primers', NULL, 1, '2025-12-12 07:00:28', '2025-12-12 07:00:28'),
(134, 'Specialty Paint', 'Specialty and decorative paints', NULL, 1, '2025-12-12 07:00:28', '2025-12-12 07:00:28'),
(135, 'Paint Supplies', 'Brushes, rollers, and painting accessories', NULL, 1, '2025-12-12 07:00:28', '2025-12-12 07:00:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `role` enum('admin','manager','employee') DEFAULT 'employee',
  `phone` varchar(20) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `first_name`, `last_name`, `role`, `phone`, `avatar`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin@ Shinningpaint.com', '$2b$12$eD9j1ci/iCQT1SUqhA8fzOz3vvqAnlVrrUepdQ/8uxeBYIz7tDcMu', 'Admin', 'User', 'admin', '+1-555-0001', NULL, 1, '2025-12-12 07:54:01', '2025-08-17 16:47:58', '2025-12-12 07:54:01'),
(2, 'manager@ Shinningpaint.com', '$2b$12$9aqhn5yDrM4lrzDsTppAg.VIn3jM2lnl98f8mzzUgnZUAbwRbdHSq', 'Manager', 'User', 'manager', '+1-555-0002', NULL, 1, NULL, '2025-08-17 16:47:58', '2025-08-17 16:47:58'),
(3, 'employee@ Shinningpaint.com', '$2b$12$yR0NR8Vn8Vz9QWx0En3w9Ov03p6MmOsXi9klr4Htqdsz7e4BDRiHi', 'Employee', 'User', 'employee', '+1-555-0003', NULL, 1, NULL, '2025-08-17 16:47:59', '2025-08-17 16:47:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_type` (`customer_type`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_type` (`transaction_type`),
  ADD KEY `idx_date` (`created_at`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_order_number` (`order_number`),
  ADD KEY `idx_customer` (`customer_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_date` (`order_date`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order` (`order_id`),
  ADD KEY `idx_product` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `idx_sku` (`sku`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_stock` (`stock_quantity`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_parent` (`parent_id`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_active` (`is_active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory_transactions`
--
ALTER TABLE `inventory_transactions`
  ADD CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `product_categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
